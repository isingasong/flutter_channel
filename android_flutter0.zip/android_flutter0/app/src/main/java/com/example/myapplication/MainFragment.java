package com.example.myapplication;

import androidx.fragment.app.Fragment;

/**
 * Created by Maker on 2019/7/25.
 * Description:
 */
public class MainFragment extends Fragment {
}
